import MainLayout from "@/Layout/main";

export default function Home() {
  return (
    <MainLayout>
      <p>Main page</p>
    </MainLayout>
  );
}
